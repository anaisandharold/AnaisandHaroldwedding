# Anaïs & Harold — A Winter Premiere

A responsive one-page wedding website with a theatrical, wintery and Belgian-inspired design.

## Open it

Double-click `index.html` to preview it in a browser.

## Publish it for free

### GitHub Pages
1. Create a free GitHub account and a new public repository.
2. Upload `index.html`, `styles.css` and `script.js`.
3. Open **Settings → Pages**.
4. Publish from the `main` branch and root folder.

### Netlify Drop
Drag the entire folder onto Netlify Drop. It will publish immediately with a free web address.

## Important edits

- In `script.js`, replace `YOUR_EMAIL@example.com` with your RSVP email.
- In `index.html`, replace the placeholder FAQ answers and add an RSVP deadline.
- To use Google Forms instead, create a form and replace the RSVP form with a button linking to it.
- Map links are already included and open Google Maps searches for each venue.

## Optional enhancements

- Add a French/English language switch.
- Add photographs to the story section.
- Add hotel and transport recommendations.
- Replace the subtle CSS snow with a custom animation.
- Connect a custom domain once the final design is approved.
