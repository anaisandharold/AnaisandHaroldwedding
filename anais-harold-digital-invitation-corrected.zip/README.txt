Upload this index.html to your GitHub repository and replace the previous file.
